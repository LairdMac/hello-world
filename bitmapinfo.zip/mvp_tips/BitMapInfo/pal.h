int GetPaletteSize(BITMAPINFOHEADER & hdr);
int GetPaletteSize(DWORD n);
