//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BitMapInfo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BITMAPINFO_DIALOG           102
#define IDS_BMP_FILTER                  102
#define IDS_UNKNOWN_ERROR               103
#define IDS_NO_BITMAPS                  104
#define IDR_MAINFRAME                   128
#define IDD_SHOW                        129
#define IDR_MENU                        130
#define IDR_ACCELERATOR                 132
#define IDI_JMNCO                       140
#define IDC_FILENAME                    1000
#define IDC_BROWSE                      1001
#define IDC_READ                        1002
#define IDC_DATA                        1003
#define IDC_LIMIT                       1004
#define IDC_SHOW                        1005
#define IDC_IMAGE                       1006
#define IDC_POS                         1007
#define IDM_FILE_OPEN                   32771
#define IDM_FILE_PRINT                  32772
#define IDM_FILE_EXIT                   32773
#define IDM_HELP_ABOUT                  32774
#define IDM_VIEW_BITMAP                 32775
#define IDM_EXIT                        32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
